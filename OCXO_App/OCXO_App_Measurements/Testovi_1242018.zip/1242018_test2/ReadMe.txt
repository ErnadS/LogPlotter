test izmedju dvije vrijednosti svako 100 sekund
prva vrijednost 135800, druga vrijednost 136000