1. Iskljuceno upravljanje sa PC nakon 1300 sekundi (nema potrebe da se gleda interval od 0 do 1300)
2. od 1300 do 7500 -> upravljanje rucno, ja sam stimao vrijednosti, moze se primjetiti da je jako tesko to uraditi
3. nakon 7500 mijenjano izmedju dvije vrijednosti prvo svakih 30 a onda svakih 100 sekundi.